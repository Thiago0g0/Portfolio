function calcularSomapares(min, max){
let soma = 0 
for(let i = min; i <= max; ++){
    soma+= i; 
}
return soma

}
const min  = 1 ;
const max  = 10;
const SomaPares calcularSomapares(min, max);
console.log