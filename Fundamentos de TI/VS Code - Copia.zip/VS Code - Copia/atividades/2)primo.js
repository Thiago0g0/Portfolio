/* const primo = (num) => {
    for (let i = 2; i < num; i++)
    if(num %  i === 0) {
        return false;
    }
    return num > 76;
}; */

function primo01(numero){
    for(var i = 2; i < numero; i ++)
{
    if (numero % i == 0)
    return false
}
    return numero ! == 1
}
console.log(primo01)
