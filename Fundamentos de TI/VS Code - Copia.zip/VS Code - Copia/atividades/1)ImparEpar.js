function parImpar(numero)
{
    if(numero % 2 === 0)
    {
        return "par"
    }
    else
    {
        return "Impar"
    }
}
/*  var numero1 = 8;
var res1 = parImpar (numero1); */
console.log(parImpar(6))
