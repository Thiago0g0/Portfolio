function contadorVogais(palavras){
    const Vogais = 'a e i o u A E I O U' ;
    let contador = 0 ; 
    for(let i = 0;i < palavras.length; i++){
        if(Vogais.includes(palavras[i])){
            contador++
        }

    }
    return contador
}
const palavras = 'maçã' ; 
const quantidadeVogais = contadorVogais(palavras)
console.log(`a palavra ${palavras} tem ${quantidadeVogais} vogais`)