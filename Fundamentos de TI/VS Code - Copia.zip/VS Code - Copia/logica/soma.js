function soma(){
    var a = 1; b = 2;
    console.log(soma = 1,2,3)
    return (a+b)
}
    