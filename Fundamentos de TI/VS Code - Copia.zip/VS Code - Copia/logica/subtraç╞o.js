function sub(){
    var su = -[1,2,3]

}